# Adrian Admin Tools
Android-приложение для админа. Сборка APK — автоматически через GitHub Actions (вкладка Actions / Releases).
