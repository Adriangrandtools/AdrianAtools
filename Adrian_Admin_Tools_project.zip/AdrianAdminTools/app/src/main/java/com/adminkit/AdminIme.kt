package com.adminkit

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class AdminIme : InputMethodService() {

    private val handler = Handler(Looper.getMainLooper())
    private val idBuf = StringBuilder()
    private val coordBuf = StringBuilder()
    private var tab = 0
    private lateinit var header: TextView
    private lateinit var tabRow: LinearLayout
    private lateinit var content: LinearLayout

    companion object { var instance: AdminIme? = null }

    override fun onCreate() { super.onCreate(); instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }

    // Вызывается из сервиса автоответа. true — если поле ввода сейчас активно.
    fun sendExternal(text: String): Boolean {
        if (currentInputConnection == null) return false
        send(text); return true
    }

    // Вставить текст в поле БЕЗ отправки (для «Свой ответ»).
    fun fillExternal(text: String): Boolean {
        val ic = currentInputConnection ?: return false
        ic.beginBatchEdit(); ic.deleteSurroundingText(500, 500); ic.commitText(text, 1); ic.endBatchEdit()
        return true
    }

    // Из плашки репорта: выбрать игрока и открыть вкладку НАКАЗАТЬ.
    fun openPunish(id: String) {
        idBuf.setLength(0); idBuf.append(id); tab = 2
        try { render(); refreshTabs(tabRow) } catch (_: Exception) {}
    }

    fun setTargetId(id: String) {
        idBuf.setLength(0); idBuf.append(id)
        try { render() } catch (_: Exception) {}
    }

    private val tabs = listOf("СЛЕЖКА", "ТП", "НАКАЗАТЬ", "КОМАНДЫ", "ОТВЕТЫ", "СТАТ")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- сборка интерфейса ----------

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Neon.BG)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        header = TextView(this).apply {
            textSize = 13f
            setTextColor(Neon.RED)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(14f, 0f, 0f, Neon.RED)
        }
        root.addView(header)

        tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.forEachIndexed { i, name ->
            tabRow.addView(btn(name, if (i == tab) Neon.PINK else Neon.RED) { tab = i; render(); refreshTabs(tabRow) })
        }
        tabRow.addView(btn("⌨", Neon.ORANGE) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        root.addView(HorizontalScrollView(this).apply { addView(tabRow) })

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply {
            addView(content)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(300)))

        render()
        return root
    }

    private fun refreshTabs(row: LinearLayout) {
        for (i in tabs.indices) {
            val v = row.getChildAt(i) as TextView
            val col = if (i == tab) Neon.PINK else Neon.RED
            v.setTextColor(col); v.setShadowLayer(12f, 0f, 0f, col); v.background = neonBg(col)
        }
    }

    private fun render() {
        refreshHeader()
        content.removeAllViews()
        when (tab) {
            0 -> tabSpectate()
            1 -> tabTp()
            2 -> tabPunish()
            3 -> tabCommands()
            4 -> tabAnswers()
            else -> tabStats()
        }
    }

    private fun refreshHeader() {
        val id = if (idBuf.isEmpty()) "—" else idBuf.toString()
        header.text = "ADRIAN TOOLS  •  LVL ${Config.level(this)}  •  ID: $id"
    }

    // ---------- вкладки ----------

    private fun tabSpectate() {
        val idView = label("ID игрока: ${if (idBuf.isEmpty()) "—" else idBuf}")
        content.addView(idView)
        content.addView(keypad(idBuf) { idView.text = "ID игрока: ${if (idBuf.isEmpty()) "—" else idBuf}"; refreshHeader() })
        content.addView(row(
            btn("СЛЕДИТЬ  /sp", Neon.PINK) { run(listOf("/sp {id}")) },
            btn("СТОП  /sp off", Neon.ORANGE) { run(listOf("/sp off")) }
        ))
        content.addView(label("СИТУАЦИИ"))
        grid(Config.situations.map { s -> btn(s.label, Neon.RED) { run(s.cmds) } }, 2)
    }

    private fun tabTp() {
        val v = label("X Y Z: ${if (coordBuf.isEmpty()) "—" else coordBuf}")
        content.addView(v)
        content.addView(keypad(coordBuf) { v.text = "X Y Z: ${if (coordBuf.isEmpty()) "—" else coordBuf}" })
        content.addView(row(
            btn("ТЕЛЕПОРТ", Neon.PINK) { runCoords(coordBuf.toString()) },
            btn("СОХРАНИТЬ ТОЧКУ", Neon.ORANGE) { savePoint() }
        ))
        val pts = Config.points(this)
        content.addView(label("СОХРАНЁННЫЕ (долгий тап — удалить)"))
        if (pts.isEmpty()) content.addView(label("пока нет"))
        grid(pts.map { pt ->
            btn("${pt.first}\n${pt.second}", Neon.RED, onLong = {
                val l = Config.points(this); l.remove(pt); Config.savePoints(this, l); render()
            }) { runCoords(pt.second) }
        }, 2)
    }

    private fun tabPunish() {
        val auto = Config.level(this) <= Config.aLevel(this)
        val idView = label("ID: ${if (idBuf.isEmpty()) "—" else idBuf}   •   твой лвл ${Config.level(this)}   •   в /a: ${if (auto) "ПИШЕТСЯ САМО" else "не нужно"}")
        content.addView(idView)
        content.addView(keypad(idBuf) {
            idView.text = "ID: ${if (idBuf.isEmpty()) "—" else idBuf}   •   твой лвл ${Config.level(this)}   •   в /a: ${if (auto) "ПИШЕТСЯ САМО" else "не нужно"}"
            refreshHeader()
        })
        content.addView(label("НАКАЗАНИЕ (тап = выдать${if (auto) " + написать в /a" else ""})"))
        grid(Config.punishments.map { p ->
            btn("${p.label}\n${p.type.uppercase()}${if (p.time > 0) " ${p.time}" else ""}", Neon.RED) { runPunish(p) }
        }, 2)
    }

    private fun runPunish(p: Punish) {
        if (idBuf.isEmpty()) { toast("Сначала введи ID игрока"); return }
        val id = idBuf.toString()
        fun f(t: String) = t.replace("{id}", id).replace("{time}", p.time.toString())
            .replace("{reason}", p.reason).replace("{type}", p.type.replaceFirstChar { it.uppercase() })
        val cmds = mutableListOf(f(Config.punishTemplate(this, p.type)))
        if (Config.level(this) <= Config.aLevel(this)) cmds.add(f(Config.aTemplate(this)))
        Stats.log(this, "${p.type.uppercase()} $id — ${p.reason}")
        run(cmds)
    }

    private fun tabCommands() {
        content.addView(label("Команды для ID: ${if (idBuf.isEmpty()) "— (введи во вкладке СЛЕЖКА)" else idBuf}"))
        grid(Config.commands.map { c -> btn(c.replace(" {id}", ""), Neon.RED) { run(listOf(c)) } }, 3)
    }

    private fun tabAnswers() {
        content.addView(label("Ответ игроку ID: ${if (idBuf.isEmpty()) "—" else idBuf}"))
        Config.answers.forEach { a ->
            content.addView(row(btn(a, Neon.PINK) { run(listOf("/ans {id} $a")) }))
        }
    }

    private fun tabStats() {
        content.addView(TextView(this).apply {
            text = Stats.report(this@AdminIme)
            textSize = 14f; setTextColor(Neon.WHITE); setPadding(dp(10), dp(10), dp(10), dp(10))
            setShadowLayer(8f, 0f, 0f, Neon.RED)
        })
    }

    // ---------- отправка команд в игру ----------

    private fun fill(cmd: String): String? {
        if (cmd.contains("{id}")) {
            if (idBuf.isEmpty()) { toast("Сначала введи ID игрока"); return null }
            return cmd.replace("{id}", idBuf.toString())
        }
        return cmd
    }

    private fun run(cmds: List<String>) {
        val ready = cmds.map { fill(it) ?: return }
        ready.forEachIndexed { i, c ->
            handler.postDelayed({ send(c) }, i * Config.delayMs(this).toLong())
        }
        Stats.add(this, ready.first())
    }

    private fun runCoords(text: String) {
        val p = text.trim().split(Regex("\\s+"))
        if (p.size != 3 || p.any { it.toDoubleOrNull() == null }) { toast("Нужно 3 числа: X Y Z"); return }
        val cmd = Config.tpTemplate(this).replace("{x}", p[0]).replace("{y}", p[1]).replace("{z}", p[2])
        send(cmd); Stats.add(this, cmd)
    }

    private fun savePoint() {
        val p = coordBuf.toString().trim()
        if (p.split(Regex("\\s+")).size != 3) { toast("Сначала введи X Y Z"); return }
        val l = Config.points(this); l.add("Точка ${l.size + 1}" to p); Config.savePoints(this, l); render()
    }

    private fun send(text: String) {
        val ic = currentInputConnection ?: run { toast("Открой чат игры — поле ввода не активно"); return }
        ic.beginBatchEdit()
        ic.deleteSurroundingText(500, 500)
        ic.commitText(text, 1)
        ic.endBatchEdit()
        if (!ic.performEditorAction(EditorInfo.IME_ACTION_SEND)) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- неоновые кирпичики ----------

    private fun neonBg(color: Int) = GradientDrawable().apply {
        setColor(Neon.CARD); cornerRadius = dp(14).toFloat(); setStroke(dp(2), color)
    }

    private fun btn(text: String, color: Int, onLong: (() -> Unit)? = null, onClick: () -> Unit) =
        TextView(this).apply {
            this.text = text; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(color); setShadowLayer(12f, 0f, 0f, color)
            gravity = Gravity.CENTER; background = neonBg(color)
            setPadding(dp(8), dp(11), dp(8), dp(11))
            setOnClickListener { performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(Neon.WHITE); setPadding(dp(8), dp(6), dp(8), dp(2))
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) }
    }

    private fun grid(items: List<View>, cols: Int) {
        items.chunked(cols).forEach { chunk ->
            val r = row(*chunk.toTypedArray())
            repeat(cols - chunk.size) {
                r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            content.addView(r)
        }
    }

    private fun keypad(target: StringBuilder, changed: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun key(k: String) = btn(k, Neon.RED) { target.append(k); changed() }
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("-", "0", ".")).forEach { r ->
            box.addView(row(*r.map { key(it) }.toTypedArray()))
        }
        box.addView(row(
            btn("пробел", Neon.ORANGE) { target.append(" "); changed() },
            btn("⌫", Neon.ORANGE) { if (target.isNotEmpty()) target.deleteCharAt(target.length - 1); changed() },
            btn("сброс", Neon.ORANGE) { target.setLength(0); changed() }
        ))
        return box
    }
}
