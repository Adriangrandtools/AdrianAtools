package com.adminkit

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * ADRIAN ADMIN TOOLS — полуавтомат по репортам.
 * 1) Плавающий кружок (время + счётчик ответов) — тап открывает меню.
 * 2) «Область чата» — обводишь пальцем, где в игре чат; репорты ищутся только там.
 * 3) Новый репорт → яркая плашка с кнопками. Без твоего нажатия ничего не отправляется.
 * 4) Строки репортов в чате подсвечиваются ярко-оранжевым.
 *
 * Формат строки (как в оригинале и на твоих скринах):  23:38 <ADM> (3) Ник_Имя[234]: текст
 */
class AutoReportService : AccessibilityService() {

    companion object { var instance: AutoReportService? = null }

    private class Hit(val num: String, val nick: String, val id: String, val text: String, val rect: Rect) {
        val key = "$num|$id|$text"
    }

    private val TYPE = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
    private val REPORT = Regex("""<ADM>\s*\((\d+)\)\s*([^\[\]]+?)\s*\[(\d+)]:\s*(.+)$""")
    private val handler = Handler(Looper.getMainLooper())
    private val seen = LinkedHashSet<String>()
    private var primed = false
    private val cleared = HashSet<String>()
    private var clearPending = false
    private var trash: TextView? = null
    private var trashLp: WindowManager.LayoutParams? = null
    private var lastTrashTap = 0L
    private var lastScan = 0L

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private var card: View? = null
    private var highlight: HighlightView? = null
    private var areaView: View? = null
    private val hideTask = Runnable { removeCard() }
    private val tickTask = object : Runnable {
        override fun run() { updateBubble(); handler.postDelayed(this, 20000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ================= жизненный цикл =================

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
        handler.post(tickTask)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        handler.removeCallbacksAndMessages(null)
        removeCard(); removeMenu()
        bubble?.let { safeRemove(it) }; bubble = null
        trash?.let { safeRemove(it) }; trash = null
        highlight?.let { safeRemove(it) }; highlight = null
        areaView?.let { safeRemove(it) }; areaView = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    private fun safeRemove(v: View) { try { wm.removeView(v) } catch (_: Exception) {} }

    // ================= область чата =================

    private fun getArea(): Rect? {
        val s = Config.p(this).getString("area", null) ?: return null
        val p = s.split(",").mapNotNull { it.toIntOrNull() }
        return if (p.size == 4) Rect(p[0], p[1], p[2], p[3]) else null
    }

    private fun startArea() {
        removeMenu()
        val v = AreaView { r ->
            Config.p(this).edit().putString("area", "${r.left},${r.top},${r.right},${r.bottom}").apply()
            areaView?.let { safeRemove(it) }; areaView = null
            Toast.makeText(this, "Область чата сохранена ✔", Toast.LENGTH_SHORT).show()
            primed = false
        }
        val lp = WindowManager.LayoutParams(
            -1, -1, TYPE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(v, lp); areaView = v } catch (_: Exception) {}
    }

    private inner class AreaView(val done: (Rect) -> Unit) : View(this@AutoReportService) {
        private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f
        private var drawing = false
        private val loc = IntArray(2)
        private val stroke = Paint().apply { style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat(); color = Neon.RED }
        private val fill = Paint().apply { color = 0x33FF1744 }
        private val txt = Paint().apply { color = Color.WHITE; textSize = dp(18).toFloat(); isFakeBoldText = true; textAlign = Paint.Align.CENTER }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ex = sx; ey = sy; drawing = true }
                MotionEvent.ACTION_MOVE -> { ex = e.rawX; ey = e.rawY }
                MotionEvent.ACTION_UP -> {
                    ex = e.rawX; ey = e.rawY; drawing = false
                    val r = Rect(minOf(sx, ex).toInt(), minOf(sy, ey).toInt(), maxOf(sx, ex).toInt(), maxOf(sy, ey).toInt())
                    if (r.width() > dp(40) && r.height() > dp(30)) done(r)
                    else Toast.makeText(context, "Слишком маленькая область, попробуй ещё раз", Toast.LENGTH_SHORT).show()
                }
            }
            invalidate(); return true
        }

        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            c.drawColor(0x88000000.toInt())
            c.drawText("Обведи пальцем область ЧАТА (где приходят репорты)", width / 2f, dp(40).toFloat(), txt)
            if (drawing) {
                val l = minOf(sx, ex) - loc[0]; val t = minOf(sy, ey) - loc[1]
                val r = maxOf(sx, ex) - loc[0]; val b = maxOf(sy, ey) - loc[1]
                c.drawRect(l, t, r, b, fill); c.drawRect(l, t, r, b, stroke)
            }
        }
    }

    // ================= подсветка репортов в чате =================

    private inner class HighlightView : View(this@AutoReportService) {
        var rects: List<Rect> = emptyList()
        private val loc = IntArray(2)
        private val fill = Paint().apply { color = 0x66FF6D00 }
        private val bar = Paint().apply { color = 0xFFFFD600.toInt() }
        private val line = Paint().apply { style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); color = Neon.RED }
        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            c.translate(-loc[0].toFloat(), -loc[1].toFloat())
            for (r in rects) {
                c.drawRect(r, fill); c.drawRect(r, line)
                c.drawRect(r.left.toFloat(), r.top.toFloat(), r.left + dp(5).toFloat(), r.bottom.toFloat(), bar)
            }
        }
    }

    private fun updateHighlight(rects: List<Rect>) {
        if (highlight == null) {
            if (rects.isEmpty()) return
            val v = HighlightView()
            val lp = WindowManager.LayoutParams(
                -1, -1, TYPE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            try { wm.addView(v, lp); highlight = v } catch (_: Exception) { return }
        }
        highlight?.rects = rects
        highlight?.invalidate()
    }

    // ================= сканирование чата =================

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!Config.autoReportOn(this)) { updateHighlight(emptyList()); return }
        val now = SystemClock.uptimeMillis()
        if (now - lastScan < 400) return
        lastScan = now

        val root = rootInActiveWindow ?: return
        val nodes = ArrayList<Pair<String, Rect>>()
        collect(root, nodes, getArea(), 0)

        val hits = ArrayList<Hit>()
        for ((text, rect) in nodes) {
            val lines = text.split("\n")
            lines.forEachIndexed { i, line ->
                val m = REPORT.find(line) ?: return@forEachIndexed
                val r = if (lines.size > 1) {
                    val h = rect.height() / lines.size
                    Rect(rect.left, rect.top + i * h, rect.right, rect.top + (i + 1) * h)
                } else Rect(rect)
                hits.add(Hit(m.groupValues[1], m.groupValues[2].trim(), m.groupValues[3], m.groupValues[4].trim(), r))
            }
        }
        if (clearPending) {                                  // после очистки: всё, что видно сейчас, считаем старым
            clearPending = false
            hits.forEach { cleared.add(it.key); seen.add(it.key) }
            updateHighlight(emptyList()); primed = true
            return
        }
        if (cleared.size > 400) cleared.clear()
        val live = hits.filter { it.key !in cleared }
        updateHighlight(live.map { it.rect })

        val fresh = live.filter { seen.add(it.key) }
        if (seen.size > 300) { val it = seen.iterator(); repeat(100) { if (it.hasNext()) { it.next(); it.remove() } } }

        if (!primed) { primed = true; return }          // старые репорты при включении не показываем
        if (fresh.isEmpty() || fresh.size > 3) return    // много «новых» сразу = прокрутка истории
        val h = fresh.last()
        showCard(h.id, h.nick, h.text)
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<Pair<String, Rect>>, area: Rect?, depth: Int) {
        if (n == null || depth > 25) return
        val r = Rect(); n.getBoundsInScreen(r)
        if (area != null && r.width() > 0 && !Rect.intersects(area, r)) return
        val t = n.text?.toString()
        if (!t.isNullOrBlank()) out.add(t to r)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, area, depth + 1)
    }

    // ================= плавающий кружок =================

    private fun showBubble() {
        val v = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 9f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Neon.WHITE); setShadowLayer(8f, 0f, 0f, Neon.RED)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xEE16040B.toInt()); setStroke(dp(2), Neon.RED) }
        }
        val lp = WindowManager.LayoutParams(
            dp(60), dp(60), TYPE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = resources.displayMetrics.widthPixels / 2 + dp(120); y = dp(4) }

        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) { lp.x = ox + dx; lp.y = oy + dy; try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}; placeTrash() }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) toggleMenu()
                }
                return true
            }
        })
        try { wm.addView(v, lp); bubble = v; bubbleLp = lp } catch (_: Exception) {}
        showTrash()
        updateBubble()
    }

    // ----- мусорка: двойной тап = очистить всё -----
    private fun showTrash() {
        val t = TextView(this).apply {
            text = "🗑"; textSize = 20f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xEE16040B.toInt()); setStroke(dp(2), Neon.ORANGE) }
            setOnClickListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastTrashTap < 700) { lastTrashTap = 0; clearAll() }
                else { lastTrashTap = now; Toast.makeText(this@AutoReportService, "Тапни ещё раз — очистить всё", Toast.LENGTH_SHORT).show() }
            }
        }
        val lp = WindowManager.LayoutParams(dp(44), dp(44), TYPE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START }
        try { wm.addView(t, lp); trash = t; trashLp = lp; placeTrash() } catch (_: Exception) {}
    }

    private fun placeTrash() {
        val b = bubbleLp ?: return; val l = trashLp ?: return; val t = trash ?: return
        l.x = b.x + dp(64); l.y = b.y + dp(8)
        try { wm.updateViewLayout(t, l) } catch (_: Exception) {}
    }

    private fun clearAll() {
        removeCard(); removeMenu()
        seen.clear(); clearPending = true
        updateHighlight(emptyList())
        Toast.makeText(this, "Всё очищено ✔ Новые репорты появятся заново", Toast.LENGTH_SHORT).show()
        lastScan = 0; onAccessibilityEvent(null)
    }

    private fun updateBubble() {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).apply { timeZone = java.util.TimeZone.getTimeZone("Europe/Moscow") }.format(Date())
        bubble?.text = "ADRIAN\n$time\nРЕП ${Config.p(this).getInt("reports", 0)}"
    }

    private fun toggleMenu() { if (menu != null) removeMenu() else showMenu() }

    private fun removeMenu() { menu?.let { safeRemove(it) }; menu = null }

    private fun showMenu() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(Neon.RED); setPadding(dp(8), dp(6), dp(8), dp(10))
        }
        box.addView(menuBtn("ОБЛАСТЬ ЧАТА", Neon.PINK) { startArea() })
        box.addView(menuBtn(if (getArea() == null) "область не задана" else "СБРОСИТЬ ОБЛАСТЬ", Neon.ORANGE) {
            Config.p(this).edit().remove("area").apply(); removeMenu()
        })
        val tog = menuBtn("", Neon.RED) {}
        fun label() { tog.text = if (Config.autoReportOn(this)) "АВТООТВЕТ: ВКЛ" else "АВТООТВЕТ: ВЫКЛ" }
        label()
        tog.setOnClickListener { Config.p(this).edit().putBoolean("autoreport", !Config.autoReportOn(this)).apply(); label() }
        box.addView(tog)
        box.addView(menuBtn("ЗАКРЫТЬ", Neon.ORANGE) { removeMenu() })
        val b = bubbleLp
        val lp = WindowManager.LayoutParams(
            dp(210), -2, TYPE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = b?.x ?: 0; y = (b?.y ?: 0) + dp(64) }
        try { wm.addView(box, lp); menu = box } catch (_: Exception) {}
    }

    private fun menuBtn(t: String, color: Int, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(color); setShadowLayer(10f, 0f, 0f, color); background = bg(color)
        setPadding(dp(8), dp(9), dp(8), dp(9)); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, 0) }
    }

    // ================= плашка репорта =================

    private fun bg(color: Int) = GradientDrawable().apply {
        setColor(0xF016040B.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(2), color)
    }

    private fun cellBtn(t: String, color: Int, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(color); setShadowLayer(10f, 0f, 0f, color); background = bg(color)
        setPadding(dp(6), dp(10), dp(6), dp(10)); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(5), dp(3), 0) }
    }

    private fun cardWindow(box: View) {
        removeCard()
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.40).toInt(), -2, TYPE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(8); y = dp(70) }
        try { wm.addView(box, lp); card = box; handler.postDelayed(hideTask, 25000) } catch (_: Exception) {}
    }

    private fun showCard(id: String, nick: String, text: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(Neon.RED); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        box.addView(TextView(this).apply {
            this.text = "🚨 РЕПОРТ  $nick [$id]"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Neon.RED); setShadowLayer(16f, 0f, 0f, Neon.RED)
        })
        box.addView(TextView(this).apply {
            this.text = text; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; maxLines = 4
            setTextColor(0xFFFFAB00.toInt()); setShadowLayer(10f, 0f, 0f, 0xFFFF6D00.toInt()); setPadding(0, dp(4), 0, dp(2))
        })
        fun r(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } }
        box.addView(r(
            cellBtn("✔ ПРИНЯТЬ", 0xFF00E676.toInt()) { sendAns(id, Config.autoAnswer(this)) },
            cellBtn("✖ ОТКАЗАТЬ", Neon.RED) { removeCard() }   // просто убрать, ничего не отправляя
        ))
        box.addView(r(
            cellBtn("БЫСТРЫЙ ОТВЕТ", Neon.PINK) { showAnswers(id, nick, text) },
            cellBtn("СВОЙ ОТВЕТ", Neon.PINK) { ownAnswer(id) }
        ))
        box.addView(r(
            cellBtn("👁 СЛЕДИТЬ", Neon.ORANGE) { ime("/sp $id", id) },
            cellBtn("ТП к игроку", Neon.ORANGE) { ime("/goto $id", id) }
        ))
        box.addView(r(
            cellBtn("⚖ НАКАЗАТЬ", Neon.RED) { punish(id) },
            cellBtn("В /a", 0xFF40C4FF.toInt()) { ime("/a Репорт от $nick[$id]: $text", null, closeAfter = true) }
        ))
        cardWindow(box)
    }

    private fun showAnswers(id: String, nick: String, text: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(Neon.PINK); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        box.addView(TextView(this).apply {
            this.text = "БЫСТРЫЙ ОТВЕТ → $nick [$id]"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Neon.PINK)
        })
        Config.answers.forEach { a ->
            box.addView(cellBtn(a, Neon.WHITE) { sendAns(id, a) }.apply {
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, 0) }
            })
        }
        box.addView(cellBtn("← НАЗАД", Neon.ORANGE) { showCard(id, nick, text) }.apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, 0) }
        })
        cardWindow(box)
    }

    // ================= отправка =================

    private fun noChat() = Toast.makeText(this,
        "Открой чат в игре с клавиатурой Adrian Tools и нажми ещё раз", Toast.LENGTH_LONG).show()

    private fun sendAns(id: String, text: String) {
        val ime = AdminIme.instance
        if (ime != null && ime.sendExternal("/ans $id $text")) {
            Stats.add(this, "/ans"); Stats.addReport(this); updateBubble(); removeCard()
        } else noChat()
    }

    private fun punish(id: String) {
        val ime = AdminIme.instance
        if (ime != null) { ime.openPunish(id); removeCard() } else noChat()
    }

    private fun ownAnswer(id: String) {
        val ime = AdminIme.instance
        if (ime != null && ime.fillExternal("/ans $id ")) removeCard() else noChat()
    }

    private fun ime(cmd: String, targetId: String?, closeAfter: Boolean = false) {
        val ime = AdminIme.instance
        if (ime != null && ime.sendExternal(cmd)) {
            if (targetId != null) ime.setTargetId(targetId)
            Stats.add(this, cmd)
            if (closeAfter) removeCard()
        } else noChat()
    }

    private fun removeCard() {
        handler.removeCallbacks(hideTask)
        card?.let { safeRemove(it) }; card = null
    }
}
