package com.adminkit

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Neon.BG); setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        box.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(260))
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        })
        box.addView(btn("1. ВКЛЮЧИТЬ КЛАВИАТУРУ", Neon.PINK) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        box.addView(btn("2. ВЫБРАТЬ КЛАВИАТУРУ", Neon.RED) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        box.addView(btn("3. ВКЛЮЧИТЬ АВТООТВЕТ (Спец. возможности → Adrian Admin Tools)", Neon.ORANGE) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        val tog = btn(if (Config.autoReportOn(this)) "АВТООТВЕТ НА РЕПОРТЫ: ВКЛ" else "АВТООТВЕТ НА РЕПОРТЫ: ВЫКЛ", Neon.PINK) {}
        tog.setOnClickListener {
            val now = !Config.autoReportOn(this)
            Config.p(this).edit().putBoolean("autoreport", now).apply()
            tog.text = if (now) "АВТООТВЕТ НА РЕПОРТЫ: ВКЛ" else "АВТООТВЕТ НА РЕПОРТЫ: ВЫКЛ"
        }
        box.addView(tog)
        box.addView(hint("4. В игре появится красный кружок ADRIAN. Тапни по нему → «ОБЛАСТЬ ЧАТА» и обведи пальцем чат с репортами. Дальше новые репорты сами вылетают плашкой, а строки репортов в чате подсвечиваются оранжевым.\n\nДальше: открой чат в игре — вместо клавиатуры появится админ-панель. Кнопка ⌨ внутри панели возвращает обычную клавиатуру."))

        val lvl = field("Твой уровень админки", Config.level(this).toString(), true)
        val tp = field("Команда ТП по координатам ({x} {y} {z})", Config.tpTemplate(this), false)
        val ans = field("Текст автоответа на репорт", Config.autoAnswer(this), false)
        val alvl = field("Писать в /a после наказания, если мой уровень не выше", Config.aLevel(this).toString(), true)
        val atpl = field("Сообщение в /a ({type} {id} {time} {reason})", Config.aTemplate(this), false)
        val ptpl = field("Команды наказаний (тип=команда, по строке). Проверь под свой сервер!", Config.punishTemplates(this), false)
        val delay = field("Пауза между командами в макросах, мс", Config.delayMs(this).toString(), true)
        box.addView(lvl.first); box.addView(lvl.second)
        box.addView(tp.first); box.addView(tp.second)
        box.addView(ans.first); box.addView(ans.second)
        box.addView(alvl.first); box.addView(alvl.second)
        box.addView(atpl.first); box.addView(atpl.second)
        box.addView(ptpl.first); box.addView(ptpl.second)
        box.addView(delay.first); box.addView(delay.second)

        box.addView(btn("СОХРАНИТЬ", Neon.ORANGE) {
            Config.p(this).edit()
                .putInt("lvl", lvl.second.text.toString().toIntOrNull() ?: 2)
                .putString("tp", tp.second.text.toString().ifBlank { "/tp {x} {y} {z}" })
                .putString("autoans", ans.second.text.toString().ifBlank { Config.autoAnswer(this) })
                .putInt("alevel", alvl.second.text.toString().toIntOrNull() ?: 2)
                .putString("atpl", atpl.second.text.toString().ifBlank { Config.aTemplate(this) })
                .putString("ptpl", ptpl.second.text.toString().ifBlank { Config.DEFAULT_PUNISH })
                .putInt("delay", delay.second.text.toString().toIntOrNull() ?: 900).apply()
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(Neon.BG); addView(box) })
    }

    private fun bg(color: Int) = GradientDrawable().apply {
        setColor(Neon.CARD); cornerRadius = dp(16).toFloat(); setStroke(dp(2), color)
    }

    private fun btn(t: String, color: Int, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(color); setShadowLayer(14f, 0f, 0f, color); background = bg(color)
        setPadding(dp(12), dp(16), dp(12), dp(16)); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(12), 0, 0) }
    }

    private fun hint(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(Neon.WHITE); setPadding(dp(4), dp(12), dp(4), dp(4))
    }

    private fun field(title: String, value: String, number: Boolean): Pair<TextView, EditText> {
        val label = TextView(this).apply {
            text = title; textSize = 12f; setTextColor(Neon.PINK); setPadding(dp(4), dp(18), 0, dp(4))
        }
        val edit = EditText(this).apply {
            setText(value); setTextColor(Neon.WHITE); background = bg(Neon.RED)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
        }
        return label to edit
    }
}
