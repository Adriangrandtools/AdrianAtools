package com.adminkit

import android.content.Context
import android.content.SharedPreferences

object Neon {
    const val BG = 0xFF0A0006.toInt()
    const val CARD = 0xFF16040B.toInt()
    const val RED = 0xFFFF1744.toInt()
    const val PINK = 0xFFFF4081.toInt()
    const val ORANGE = 0xFFFF6D00.toInt()
    const val WHITE = 0xFFFFE6EA.toInt()
}

class Situation(val label: String, val cmds: List<String>)
class Punish(val label: String, val type: String, val time: Int, val reason: String)

object Config {
    fun p(c: Context): SharedPreferences = c.getSharedPreferences("adminkit", Context.MODE_PRIVATE)

    fun level(c: Context) = p(c).getInt("lvl", 2)
    fun autoReportOn(c: Context) = p(c).getBoolean("autoreport", true)
    fun autoAnswer(c: Context) = p(c).getString("autoans", "Здравствуйте, сейчас постараюсь вам помочь.")
        ?: "Здравствуйте, сейчас постараюсь вам помочь."
    // Если твой уровень <= этого числа, после наказания сам пишется текст в админ-чат /a
    fun aLevel(c: Context) = p(c).getInt("alevel", 2)
    fun aTemplate(c: Context) = p(c).getString("atpl", "/a {type} {id} на {time} мин. Причина: {reason}")
        ?: "/a {type} {id} на {time} мин. Причина: {reason}"
    const val DEFAULT_PUNISH = "jail=/jail {id} {time} {reason}\nmute=/mute {id} {time} {reason}\nban=/ban {id} {time} {reason}\nkick=/kick {id} {reason}\nwarn=/warn {id} {reason}"
    fun punishTemplates(c: Context) = p(c).getString("ptpl", DEFAULT_PUNISH) ?: DEFAULT_PUNISH
    fun punishTemplate(c: Context, type: String): String {
        val line = punishTemplates(c).lines().firstOrNull { it.startsWith("$type=") }
        return line?.substringAfter("=")?.trim() ?: "/$type {id} {time} {reason}"
    }

    // Пресеты наказаний (примеры — поменяй время и причины под правила своего сервера)
    val punishments = listOf(
        Punish("DM", "jail", 30, "DM"),
        Punish("DB", "jail", 30, "DB"),
        Punish("Оск. игроков", "mute", 30, "Оск. игроков"),
        Punish("Оск. администрации", "mute", 60, "Оск. администрации"),
        Punish("Упом. родных", "mute", 120, "Упоминание родных"),
        Punish("Чит / софт", "ban", 7, "Читы"),
        Punish("Кик: помеха", "kick", 0, "Помеха другим игрокам")
    )

    fun delayMs(c: Context) = p(c).getInt("delay", 900)

    // ВАЖНО: проверь на своём сервере, какая команда телепортирует по координатам, и поменяй в настройках.
    fun tpTemplate(c: Context) = p(c).getString("tp", "/tp {x} {y} {z}") ?: "/tp {x} {y} {z}"

    // Ситуации при слежке: кнопка -> команды (по очереди). {id} подставляется сам.
    val situations = listOf(
        Situation("Упал в воду с машиной", listOf("/getcar {id}")),
        Situation("Починить авто", listOf("/fixcar {id}")),
        Situation("Перевернулась", listOf("/flip {id}")),
        Situation("Застрял / баг", listOf("/slap {id}")),
        Situation("Вылечить", listOf("/heal {id}")),
        Situation("ТП к себе", listOf("/gethere {id}")),
        Situation("Помочь: ТП + хил", listOf("/goto {id}", "/heal {id}")),
        Situation("Заморозить", listOf("/freeze {id}"))
    )

    val commands = listOf(
        "/goto {id}", "/gethere {id}", "/slap {id}", "/heal {id}", "/spawn {id}", "/freeze {id}",
        "/uncuff {id}", "/untie {id}", "/stats {id}", "/weap {id}", "/rgun {id}", "/deadlist {id}"
    )

    // Быстрые ответы: отправляются как /ans {id} текст
    val answers = listOf(
        "Здравствуйте! Уже помогаю вам.",
        "Приятной игры на сервере!",
        "Ожидайте, рассматриваю вашу ситуацию.",
        "Игрок будет наказан, спасибо за репорт.",
        "Нарушений не обнаружено.",
        "Обратитесь на форум в раздел жалоб."
    )

    fun points(c: Context): MutableList<Pair<String, String>> =
        (p(c).getString("points", "") ?: "").split("\n").filter { it.contains("|") }
            .map { it.substringBefore("|") to it.substringAfter("|") }.toMutableList()

    fun savePoints(c: Context, list: List<Pair<String, String>>) {
        p(c).edit().putString("points", list.joinToString("\n") { "${it.first}|${it.second}" }).apply()
    }
}

object Stats {
    private fun dayKey() = "d:" + java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())

    fun add(c: Context, cmd: String) {
        val key = "c:" + cmd.trim().substringBefore(" ")
        val day = dayKey()
        val sp = Config.p(c)
        sp.edit().putInt(key, sp.getInt(key, 0) + 1)
            .putInt(day, sp.getInt(day, 0) + 1)
            .putInt("total", sp.getInt("total", 0) + 1).apply()
    }

    fun addReport(c: Context) {
        val sp = Config.p(c); sp.edit().putInt("reports", sp.getInt("reports", 0) + 1).apply()
    }

    fun log(c: Context, line: String) {
        val sp = Config.p(c)
        val t = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        val all = (sp.getString("plog", "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        all.add("$t  $line")
        sp.edit().putString("plog", all.takeLast(30).joinToString("\n")).apply()
    }

    fun report(c: Context): String {
        val sp = Config.p(c)
        val top = sp.all.filter { it.key.startsWith("c:") }
            .map { it.key.removePrefix("c:") to (it.value as Int) }
            .sortedByDescending { it.second }.take(6)
        val sb = StringBuilder()
        sb.append("Сегодня команд: ${sp.getInt(dayKey(), 0)}\nВсего: ${sp.getInt("total", 0)}\nОтвечено репортов: ${sp.getInt("reports", 0)}\n\nТОП команд:\n")
        if (top.isEmpty()) sb.append("пока пусто") else top.forEach { sb.append("${it.first}  —  ${it.second}\n") }
        val hist = (sp.getString("plog", "") ?: "").split("\n").filter { it.isNotBlank() }.takeLast(8).reversed()
        sb.append("\n\nПОСЛЕДНИЕ НАКАЗАНИЯ:\n")
        if (hist.isEmpty()) sb.append("пока нет") else hist.forEach { sb.append(it).append("\n") }
        return sb.toString()
    }
}
